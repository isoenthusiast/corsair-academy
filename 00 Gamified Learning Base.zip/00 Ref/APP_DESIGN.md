# Gamified Learning App — Design & Architecture

**Last Updated:** July 25, 2026 (v1.0.0)
**Code Name:** "QuestLab"
**Stack:** Next.js 16 + Prisma + PostgreSQL + NextAuth v5

---

## 1. Architecture Overview

```
┌──────────────────────────────────────────────┐
│  Browser (Next.js 16, React, Tailwind)       │
│  ├─ /learn          → Quest dashboard        │
│  ├─ /quest/[id]     → Active challenge       │
│  ├─ /profile        → Avatar, stats, badges  │
│  └─ /parent         → Parent dashboard       │
├──────────────────────────────────────────────┤
│  API Routes (Next.js Route Handlers)         │
│  ├─ /api/quests       → CRUD quests          │
│  ├─ /api/challenges   → Generate + grade     │
│  ├─ /api/gamification → XP, badges, streaks  │
│  ├─ /api/ai/tutor     → AI chat tutor        │
│  └─ /api/ai/generate  → AI question gen      │
├──────────────────────────────────────────────┤
│  Prisma ORM → PostgreSQL                     │
└──────────────────────────────────────────────┘
```

## 2. Data Model

### Core Models

```prisma
model User {
  id            String    @id @default(cuid())
  name          String
  username      String    @unique
  passwordHash  String
  role          Role      @default(Learner)
  avatarUrl     String?
  age           Int?      // For difficulty adaptation
  createdAt     DateTime  @default(now())
  
  progress      UserQuestProgress[]
  achievements  UserAchievement[]
  pointLog      PointTransaction[]
  streaks       Streak[]
}

model World {
  id          String    @id @default(cuid())
  name        String    @unique        // "Math", "Science", "Language"
  icon        String                    // Emoji or icon name
  description String?
  color       String?                   // Theme color
  sortOrder   Int       @default(0)
  quests      Quest[]
}

model Quest {
  id            String    @id @default(cuid())
  title         String
  description   String?
  worldId       String
  sortOrder     Int       @default(0)
  difficulty    Int       @default(1)   // 1-5
  requiredQuestId String?               // Prerequisite quest
  bossLevel     Boolean   @default(false)
  createdAt     DateTime  @default(now())
  
  world         World     @relation(fields: [worldId], references: [id])
  challenges    Challenge[]
  prerequisites Quest?    @relation("QuestPrerequisite", fields: [requiredQuestId], references: [id])
  progress      UserQuestProgress[]
}

model Challenge {
  id            String    @id @default(cuid())
  questId       String
  type          ChallengeType           // multi_choice, fill_blank, puzzle, open_ended
  question      String                  // AI-generated or curated
  options       Json?                   // For multi-choice: ["A","B","C","D"]
  answer        String                  // Correct answer
  explanation   String?                 // Shown after answering
  hint          String?                 // Power-up hint
  points        Int       @default(10)
  difficulty    Int       @default(1)   // Adaptive: adjusts based on user performance
  aiGenerated   Boolean   @default(false)
  createdAt     DateTime  @default(now())
  
  quest         Quest     @relation(fields: [questId], references: [id])
  attempts      ChallengeAttempt[]
}

model ChallengeAttempt {
  id            String    @id @default(cuid())
  challengeId   String
  userId        String
  answer        String
  correct       Boolean
  timeSpent     Int?                    // Seconds
  stars         Int       @default(0)   // 1-3
  hintsUsed     Int       @default(0)
  createdAt     DateTime  @default(now())
  
  challenge     Challenge @relation(fields: [challengeId], references: [id])
  user          User      @relation(fields: [userId], references: [id])
}

model UserQuestProgress {
  id            String    @id @default(cuid())
  userId        String
  questId       String
  status        QuestStatus @default(Locked)
  stars         Int       @default(0)
  challengesCompleted Int @default(0)
  completedAt   DateTime?
  
  user          User      @relation(fields: [userId], references: [id])
  quest         Quest     @relation(fields: [questId], references: [id])
  
  @@unique([userId, questId])
}
```

### Gamification Models

```prisma
model PointTransaction {
  id          String    @id @default(cuid())
  userId      String
  points      Int
  reason      String                  // "challenge_complete", "streak_bonus", "boss_defeated"
  sourceId    String?                 // Challenge or Quest ID
  multiplier  Float     @default(1.0)
  createdAt   DateTime  @default(now())
  
  user        User      @relation(fields: [userId], references: [id])
}

model Achievement {
  id          String    @id @default(cuid())
  name        String
  description String
  icon        String
  type        AchievementType
  threshold   Int?                    // e.g., 7 for 7-day streak
  rarity      BadgeRarity @default(Common)
}

model UserAchievement {
  id            String    @id @default(cuid())
  userId        String
  achievementId String
  earnedAt      DateTime  @default(now())
  
  user          User      @relation(fields: [userId], references: [id])
  achievement   Achievement @relation(fields: [achievementId], references: [id])
  
  @@unique([userId, achievementId])
}

model Streak {
  id          String    @id @default(cuid())
  userId      String
  currentStreak Int     @default(0)
  longestStreak Int     @default(0)
  lastActivityDate DateTime?
  streakProtection Int  @default(0)   // Free skips remaining
  
  user        User      @relation(fields: [userId], references: [id])
  @@unique([userId])
}

model PowerUp {
  id          String    @id @default(cuid())
  userId      String
  type        PowerUpType
  quantity    Int       @default(0)
  
  user        User      @relation(fields: [userId], references: [id])
  @@unique([userId, type])
}

// ── Enums ──
enum Role { Parent, Learner }
enum ChallengeType { multi_choice, fill_blank, puzzle, open_ended }
enum QuestStatus { Locked, Available, InProgress, Completed, Mastered }
enum AchievementType { streak, mastery, speed, exploration, social }
enum BadgeRarity { Common, Uncommon, Rare, Epic, Legendary }
enum PowerUpType { hint, skip, double_xp, freeze_streak }
```

## 3. Route Map

| Route | Page | Purpose |
|-------|------|---------|
| `/` | Login | Auth gate |
| `/learn` | QuestDashboard | World map + quest paths |
| `/learn/[worldId]` | WorldView | Quests in a world |
| `/quest/[id]` | ChallengePlayer | Active challenge with game UI |
| `/quest/[id]/complete` | QuestComplete | Stars, XP, next quest |
| `/profile` | Profile | Avatar, stats, badges, streaks |
| `/parent` | ParentDashboard | Progress, struggles, suggestions |
| `/parent/quests` | QuestManager | Create/edit quests (parent) |
| `/api/ai/tutor` | POST | AI chat tutor |
| `/api/ai/generate` | POST | AI generates challenge questions |

## 4. AI Integration

**Model:** DeepSeek V4 Pro (`deepseek-v4-pro`)

**Three AI Functions:**
1. **Tutor Chat** — `/api/ai/tutor` — Explains concepts, walks through problems, never gives answers directly
2. **Question Generator** — `/api/ai/generate` — Creates fresh challenges adapted to topic + difficulty + child's history
3. **Content Summarizer** — Generates quest descriptions and learning objectives

## 5. Gamification Mechanics

| Mechanic | Implementation |
|----------|---------------|
| **XP** | +10 per challenge, +50 boss, ×2 streak bonus |
| **Stars** | 1=completed, 2=correct 1st try, 3=correct 1st try + under time limit |
| **Streaks** | Daily activity tracked. 7-day streak = rare badge. Freeze protection (1/week) |
| **Power-Ups** | Earned at streak milestones (3, 7, 14, 30 days) |
| **Levels** | XP thresholds: 100→Bronze, 500→Silver, 2000→Gold, 5000→Platinum, 10000→Legend |
| **Boss Levels** | Cumulative challenge at quest end. Must score 2+ stars to unlock next quest |

## 6. Parent Dashboard

Shows per-child:
- Current quest + progress %
- Streak status + protection remaining
- Subjects where child struggles (high hint usage, low stars)
- Recent activity timeline
- Suggested conversation starters ("Ask them about fractions — they mastered it today!")
- Screen time summary

## Appendix A: Version History

| Version | Date | Changes |
|---------|------|---------|
| v1.0.0 | 2026-07-25 | Initial design — scaffold for gamified learning app |
